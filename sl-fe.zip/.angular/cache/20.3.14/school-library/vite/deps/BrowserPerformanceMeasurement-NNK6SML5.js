import {
  BrowserPerformanceMeasurement
} from "./chunk-4S55SUXD.js";
import "./chunk-35ENWJA4.js";
export {
  BrowserPerformanceMeasurement
};
